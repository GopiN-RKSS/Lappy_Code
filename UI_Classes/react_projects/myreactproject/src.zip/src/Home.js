import React from "react";

export const Home = () => {
  return (
    <>
      <div className="border border-2 border-secondary bg-dark p-5 fs-4 text-center text-white">
        I am Home Component
      </div>
    </>
  );
};
