import React from "react";

export const Services = () => {
  return (
    <>
      <div className="border border-2 border-secondary bg-secondary p-5 fs-4 text-center text-white">
        I am Services Component
      </div>
    </>
  );
};
