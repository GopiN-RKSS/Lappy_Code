import React from "react";
import "./Footer.css";

export let Footer = () => {
  return (
    <div className="footer">
      <h3>All rights Reserved</h3>
    </div>
  );
};
