import React from "react";

export const Contact = () => {
  return (
    <>
      <div className="border border-2 border-secondary bg-info p-5 fs-4 text-center text-white">
        I am Contact Component
      </div>
    </>
  );
};
