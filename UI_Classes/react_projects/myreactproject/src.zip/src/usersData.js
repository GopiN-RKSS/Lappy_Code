export const users = [
  {
    name: "Ramesh",
    person: "VIP",
  },
  {
    name: "Suresh",
    person: "Regular",
  },
  {
    name: "Gopi",
    person: "Regular",
  },
  {
    name: "Kohli",
    person: "VIP",
  },
];

export const services = {
  facilitiesVip: ["Wifi", "Fresh Kit", "Buffet", "SPA"],
  facilities: ["Wifi", "Fresh Kit"],
};
