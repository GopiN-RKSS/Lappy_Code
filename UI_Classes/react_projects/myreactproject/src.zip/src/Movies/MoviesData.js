export const data = [
  {
    title: "VakeelSaab",
    img: "images/vakeelsaab.jpg",
    name: "VakeelSaab",
  },
  {
    title: "Ala-Vaikunthapurramloo",
    img: "images/ala-vaikunthapurramloo_157104662800.jpg",
    name: "Ala-Vaikunthapurramloo",
  },
  {
    title: "Attarintiki Dharedhi",
    img: "images/Attarintiki_Dharedhi.jpg",
    name: "Attarintiki Dharedhi",
  },
  {
    title: "Bharath Ane Nenu",
    img: "images/bharath_download.jpg",
    name: "Bharath Ane Nenu",
  },
  {
    title: "RRR",
    img: "images/rrr_158512201100.jpg",
    name: "RRR",
  },
  {
    title: "VakeelSaab",
    img: "images/vakeelsaab.jpg",
    name: "VakeelSaab",
  },
];
