import React from "react";

export const About = () => {
  return (
    <>
      <div className="border border-2 border-secondary bg-success p-5 fs-4 text-center text-white">
        I am About Component
      </div>
    </>
  );
};
